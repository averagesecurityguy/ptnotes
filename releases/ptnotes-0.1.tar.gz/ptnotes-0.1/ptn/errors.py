# -*- coding: utf-8 -*-


class ScanImportError(Exception):
    pass
