# ptnotes
Simple tool for taking notes in a pentest.
